# ⛅ FUNA.PY
*Funa.py is a collection of trash functions taht do things in style.*

> [!WARNING]
> This extension is work in progress and could contain security issues. **PROCEED WITH CAUTION.**